using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Swashbuckle.AspNetCore;

using CRUD2023.Server;
using Server.Controllers;
using CRUD2023.Shared;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Server.Models;




namespace CRUD2023.Server
{
    public class Startup
    {



        public Startup(IConfiguration configuration){

            Configuration = configuration;
        }
        
public IConfiguration Configuration {get;}

public void  ConfigureServices(IServiceCollection services)
{

    services.AddControllersWithViews();
    services.AddRazorPages();

    services.AddDbContext<UserContext>(options =>
    
    options.UseSqlite(Configuration.GetConnectionString("DefaultConnection")));

    services.AddSwaggerGen(opt => opt.SwaggerDoc("v1",
    
    new Microsoft.OpenApi.Models.OpenApiInfo{
        Version = "v1",
        Title = "CRUD2023 Api"

    }
    
    ));

}








public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
{

if (env.IsDevelopment())
{
app.UseDeveloperExceptionPage();
app.UseWebAssemblyDebugging();

}
else
{
app.UseExceptionHandler("/Error");
app.UseHsts();

}

app.UseHttpsRedirection();
app.UseBlazorFrameworkFiles();
app.UseStaticFiles();
app.UseSwagger();
app.UseSwaggerUI(opt => opt.SwaggerEndpoint("/swagger/v1/swagger.json","CRUD2023 Api"));
app.UseRouting();

app.UseEndpoints(endpoints =>
{

endpoints.MapRazorPages();
endpoints.MapControllers();
endpoints.MapFallbackToFile("index.html");


});

app.UseAuthorization();



app.UseRouting();

app.UseAuthentication();
app.UseAuthorization(); // Add it here
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
});
}

    }
}





